﻿namespace _02.Customer
{
    public class Payment : IPayment
    {
        public string Name { get; }
        public decimal Price { get; }
    }
}