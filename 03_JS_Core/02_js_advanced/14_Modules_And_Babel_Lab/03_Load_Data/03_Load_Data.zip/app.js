/**
 * Created by ivans on 09-Nov-16.
 */
result.sort = require('./functions').sorting
result.filter = require('./functions').filter